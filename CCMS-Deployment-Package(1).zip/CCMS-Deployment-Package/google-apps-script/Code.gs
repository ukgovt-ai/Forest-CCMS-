/**
 * ============================================================
 *  COURT CASE MONITORING SYSTEM (CCMS) — BACKEND
 *  Forest & Allied Departments, Government of Uttarakhand
 * ============================================================
 *  Paste this whole file into Extensions ▸ Apps Script of a
 *  Google Sheet, run  setup()  once, then Deploy ▸ Web app
 *  (Execute as: Me / Access: Anyone) and copy the /exec URL.
 *
 *  Data model
 *   • Sheet "Data"     : one row per case → [id | json | updatedAt | caseNo | title]
 *   • Sheet "Register" : human-readable summary, rebuilt on every change
 *   • Sheet "Config"   : B1 = access key required by the app
 *   • Drive folder "CCMS Court Case Files" : uploaded judgment copies
 *
 *  Rules enforced here (server-side):
 *   • Action updates are APPEND-ONLY (nobody can edit another user's entry)
 *   • Only the case creator can edit particulars or delete the case
 *   • Only the assigned officer or the case creator can update an action
 *   • An action can be deleted only by its creator and only if it has no updates
 * ============================================================
 */

var DATA = "Data";
var REG = "Register";
var CFG = "Config";
var FOLDER_PROP = "CCMS_FOLDER_ID";
var MAX_FILE_BYTES = 10 * 1024 * 1024;

/* ---------- ONE-TIME SETUP (run this manually once) ---------- */
function setup() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();

  var d = ss.getSheetByName(DATA) || ss.insertSheet(DATA);
  if (d.getLastRow() === 0) d.appendRow(["id", "json", "updatedAt", "caseNumber", "title"]);
  d.hideSheet();

  var c = ss.getSheetByName(CFG) || ss.insertSheet(CFG);
  c.getRange("A1").setValue("ACCESS KEY (change this, then circulate to officers):");
  if (!String(c.getRange("B1").getValue())) c.getRange("B1").setValue("Forest@2026");
  c.getRange("A2").setValue("Officers enter this key once per device in the app.");

  var r = ss.getSheetByName(REG) || ss.insertSheet(REG);
  ss.setActiveSheet(r);

  var props = PropertiesService.getScriptProperties();
  if (!props.getProperty(FOLDER_PROP)) {
    var folder = DriveApp.createFolder("CCMS Court Case Files");
    props.setProperty(FOLDER_PROP, folder.getId());
  }
  rebuildRegister_();
  return "Setup complete. Now use Deploy ▸ New deployment ▸ Web app.";
}

/* ---------- HTTP ENTRY POINTS ---------- */
function doGet() {
  return out_({ ok: true, service: "CCMS", hint: "POST JSON {action, key, ...}" });
}

function doPost(e) {
  var req;
  try {
    req = JSON.parse(e.postData.contents);
  } catch (err) {
    return out_({ ok: false, code: "BAD_JSON", error: "Request was not valid JSON" });
  }
  try {
    if (!checkKey_(req.key)) return out_({ ok: false, code: "AUTH_KEY", error: "Invalid access key" });
    var a = String(req.action || "");
    if (a === "ping") return out_({ ok: true, service: "CCMS" });
    if (a === "list") return out_({ ok: true, cases: listCases_() });

    // everything below mutates → take a lock
    var lock = LockService.getScriptLock();
    lock.waitLock(20000);
    try {
      var res;
      if (a === "createCase") res = createCase_(req);
      else if (a === "editCase") res = editCase_(req);
      else if (a === "deleteCase") res = deleteCase_(req);
      else if (a === "addHearing") res = addHearing_(req);
      else if (a === "addActions") res = addActions_(req);
      else if (a === "addUpdate") res = addUpdate_(req);
      else if (a === "deleteAction") res = deleteAction_(req);
      else if (a === "uploadFile") res = uploadFile_(req);
      else if (a === "deleteFile") res = deleteFile_(req);
      else return out_({ ok: false, code: "BAD_ACTION", error: "Unknown action: " + a });
      rebuildRegister_();
      return out_(res);
    } finally {
      lock.releaseLock();
    }
  } catch (err) {
    return out_({ ok: false, code: "SERVER", error: String(err && err.message ? err.message : err) });
  }
}

function out_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function checkKey_(key) {
  var stored = String(SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CFG).getRange("B1").getValue()).trim();
  return stored !== "" && String(key || "").trim() === stored;
}

/* ---------- DATA HELPERS ---------- */
function sheet_() { return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(DATA); }

function listCases_() {
  var s = sheet_();
  var last = s.getLastRow();
  if (last < 2) return [];
  var rows = s.getRange(2, 1, last - 1, 2).getValues();
  var cases = [];
  for (var i = 0; i < rows.length; i++) {
    if (!rows[i][0]) continue;
    try { cases.push(JSON.parse(rows[i][1])); } catch (e) { /* skip corrupt row */ }
  }
  cases.sort(function (a, b) { return String(b.createdAt || "").localeCompare(String(a.createdAt || "")); });
  return cases;
}

function findRow_(id) {
  var s = sheet_();
  var last = s.getLastRow();
  if (last < 2) return null;
  var ids = s.getRange(2, 1, last - 1, 1).getValues();
  for (var i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === String(id)) return { row: i + 2, sheet: s };
  }
  return null;
}

function readCase_(id) {
  var f = findRow_(id);
  if (!f) return null;
  return { loc: f, c: JSON.parse(f.sheet.getRange(f.row, 2).getValue()) };
}

function writeCase_(loc, c) {
  loc.sheet.getRange(loc.row, 2, 1, 4).setValues([[JSON.stringify(c), new Date().toISOString(), c.caseNumber || "", titleOf_(c)]]);
}

function titleOf_(c) {
  var p = String(c.petitioners || "").split(/\n|,/)[0].trim() || "Petitioner";
  var r = (c.respondents && c.respondents[0] && String(c.respondents[0]).trim()) || "State of Uttarakhand & Ors.";
  return p + " vs " + r;
}

/* ---------- ACTIONS ---------- */
function createCase_(req) {
  var c = req["case"];
  if (!c || !c.id || !c.caseNumber) throw new Error("Case number is required");
  if (findRow_(c.id)) throw new Error("Duplicate entry — please refresh");
  c.hearings = c.hearings || []; c.files = c.files || []; c.actions = c.actions || [];
  var s = sheet_();
  s.appendRow([c.id, JSON.stringify(c), new Date().toISOString(), c.caseNumber, titleOf_(c)]);
  return { ok: true, "case": c };
}

function editCase_(req) {
  var r = readCase_(req.id);
  if (!r) throw new Error("Case not found — it may have been deleted");
  if (String(r.c.createdBy) !== String(req.by)) throw new Error("Only the officer who entered the case (" + r.c.createdBy + ") can edit its particulars");
  var patch = req.patch || {};
  // protected fields cannot be overwritten through edit
  delete patch.id; delete patch.createdBy; delete patch.createdAt;
  delete patch.actions; delete patch.hearings; delete patch.files;
  for (var k in patch) r.c[k] = patch[k];
  writeCase_(r.loc, r.c);
  return { ok: true, "case": r.c };
}

function deleteCase_(req) {
  var r = readCase_(req.id);
  if (!r) return { ok: true, deletedId: req.id };
  if (String(r.c.createdBy) !== String(req.by)) throw new Error("Only the officer who entered the case (" + r.c.createdBy + ") can delete it");
  // move attached Drive files to trash
  var files = r.c.files || [];
  for (var i = 0; i < files.length; i++) {
    try { if (files[i].driveId) DriveApp.getFileById(files[i].driveId).setTrashed(true); } catch (e) { /* already gone */ }
  }
  r.loc.sheet.deleteRow(r.loc.row);
  return { ok: true, deletedId: req.id };
}

function addHearing_(req) {
  var r = readCase_(req.id);
  if (!r) throw new Error("Case not found");
  var h = req.hearing || {};
  if (!h.id) throw new Error("Bad hearing payload");
  h.by = String(req.by || h.by || "");
  if (!h.by) throw new Error("Select your officer name first");
  r.c.hearings = r.c.hearings || [];
  r.c.hearings.push(h);
  r.c.nextHearingDate = h.notFixed ? null : (h.nextDate || null);
  r.c.dateNotFixed = !!h.notFixed || !h.nextDate;
  if (req.disposed) r.c.status = "Disposed";
  writeCase_(r.loc, r.c);
  return { ok: true, "case": r.c };
}

function addActions_(req) {
  var r = readCase_(req.id);
  if (!r) throw new Error("Case not found");
  var acts = req.actions || [];
  if (!acts.length) throw new Error("No actions supplied");
  r.c.actions = r.c.actions || [];
  for (var i = 0; i < acts.length; i++) {
    var a = acts[i];
    if (!a.id || !a.type) throw new Error("Bad action payload");
    a.createdBy = String(req.by || a.createdBy || "");
    a.updates = a.updates || [];
    r.c.actions.push(a);
  }
  writeCase_(r.loc, r.c);
  return { ok: true, "case": r.c };
}

function addUpdate_(req) {
  var r = readCase_(req.id);
  if (!r) throw new Error("Case not found");
  var by = String(req.by || "");
  var u = req.update || {};
  if (!u.id || !u.status) throw new Error("Bad update payload");
  var found = null;
  var acts = r.c.actions || [];
  for (var i = 0; i < acts.length; i++) if (String(acts[i].id) === String(req.actionId)) { found = acts[i]; break; }
  if (!found) throw new Error("Action not found");
  if (String(found.officer) !== by && String(r.c.createdBy) !== by) {
    throw new Error("This action is assigned to " + found.officer + " — only that officer (or the case creator) can record an update");
  }
  u.by = by;
  found.updates = found.updates || [];
  found.updates.push(u); // APPEND-ONLY: existing entries are never touched
  found.currentStatus = u.status;
  found.completedOn = u.status === "Completed" ? (u.date || null) : null;
  writeCase_(r.loc, r.c);
  return { ok: true, "case": r.c };
}

function deleteAction_(req) {
  var r = readCase_(req.id);
  if (!r) throw new Error("Case not found");
  var by = String(req.by || "");
  var acts = r.c.actions || [];
  var next = [];
  var removed = false;
  for (var i = 0; i < acts.length; i++) {
    var a = acts[i];
    if (String(a.id) === String(req.actionId)) {
      if ((a.updates || []).length > 0) throw new Error("This action already has recorded updates and cannot be deleted");
      if (String(a.createdBy) !== by) throw new Error("Only the officer who added this action can delete it");
      removed = true;
      continue;
    }
    next.push(a);
  }
  if (!removed) throw new Error("Action not found");
  r.c.actions = next;
  writeCase_(r.loc, r.c);
  return { ok: true, "case": r.c };
}

function uploadFile_(req) {
  var r = readCase_(req.id);
  if (!r) throw new Error("Case not found");
  var by = String(req.by || "");
  if (!by) throw new Error("Select your officer name first");
  var b64 = String(req.base64 || "");
  if (!b64) throw new Error("Empty file");
  var bytes = Utilities.base64Decode(b64);
  if (bytes.length > MAX_FILE_BYTES) throw new Error("File too large — max 10 MB");
  var name = String(req.name || "document");
  var blob = Utilities.newBlob(bytes, String(req.mime || "application/octet-stream"), (r.c.caseNumber || "case") + " — " + name);
  var folder = DriveApp.getFolderById(PropertiesService.getScriptProperties().getProperty(FOLDER_PROP));
  var file = folder.createFile(blob);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  var meta = {
    id: Utilities.getUuid(),
    name: name,
    size: bytes.length,
    by: by,
    at: new Date().toISOString(),
    driveId: file.getId(),
    url: "https://drive.google.com/file/d/" + file.getId() + "/view"
  };
  r.c.files = r.c.files || [];
  r.c.files.push(meta);
  writeCase_(r.loc, r.c);
  return { ok: true, "case": r.c };
}

function deleteFile_(req) {
  var r = readCase_(req.id);
  if (!r) throw new Error("Case not found");
  var by = String(req.by || "");
  var files = r.c.files || [];
  var next = [];
  var removed = null;
  for (var i = 0; i < files.length; i++) {
    var f = files[i];
    if (String(f.id) === String(req.fileId)) {
      if (String(f.by) !== by && String(r.c.createdBy) !== by) throw new Error("Only the uploader or the case creator can delete this file");
      removed = f;
      continue;
    }
    next.push(f);
  }
  if (!removed) throw new Error("File not found");
  try { if (removed.driveId) DriveApp.getFileById(removed.driveId).setTrashed(true); } catch (e) { /* ignore */ }
  r.c.files = next;
  writeCase_(r.loc, r.c);
  return { ok: true, "case": r.c };
}

/* ---------- HUMAN-READABLE REGISTER TAB ---------- */
function rebuildRegister_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var reg = ss.getSheetByName(REG) || ss.insertSheet(REG);
  reg.clearContents();
  var head = ["S.No", "Case Number", "Court", "Title", "Nature", "Status", "Next hearing", "Pending actions", "Overdue actions", "Entered by", "Entered on"];
  var rows = [head];
  var cases = listCases_();
  var today = new Date(); today.setHours(0, 0, 0, 0);
  for (var i = 0; i < cases.length; i++) {
    var c = cases[i];
    var acts = c.actions || [];
    var pend = 0, od = 0;
    for (var j = 0; j < acts.length; j++) {
      if (acts[j].currentStatus !== "Completed") {
        pend++;
        if (acts[j].dueDate && new Date(acts[j].dueDate + "T00:00:00") < today) od++;
      }
    }
    var court = c.court === "Any Other" ? (c.courtOther || "Other Court") : c.court;
    rows.push([
      i + 1, c.caseNumber || "", court || "", titleOf_(c),
      c.caseType === "Other" ? (c.caseTypeOther || "Other") : (c.caseType || ""),
      c.status || "", c.dateNotFixed ? "Not fixed" : (c.nextHearingDate || ""),
      pend, od, c.createdBy || "", String(c.createdAt || "").slice(0, 10)
    ]);
  }
  reg.getRange(1, 1, rows.length, head.length).setValues(rows);
  reg.getRange(1, 1, 1, head.length).setFontWeight("bold").setBackground("#1f5130").setFontColor("#ffffff");
  reg.setFrozenRows(1);
}
