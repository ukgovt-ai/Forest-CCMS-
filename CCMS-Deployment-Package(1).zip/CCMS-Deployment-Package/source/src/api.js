/* ============================================================
   API layer — talks to the Google Apps Script web app.
   POST body is sent as plain text (JSON string) so the browser
   makes a "simple request" and no CORS preflight is needed.
   ============================================================ */

const CFG = (typeof window !== "undefined" && window.CCMS_CONFIG) || {};

export const SCRIPT_URL = (CFG.SCRIPT_URL || "").trim();
export const scriptConfigured = () =>
  SCRIPT_URL.indexOf("https://script.google.com/") === 0 && SCRIPT_URL.indexOf("PASTE_") === -1;

/* ---- device-local settings (this phone/computer only) ---- */
const LS = {
  key: "ccms.accessKey",
  me: "ccms.identity",
  cache: "ccms.lastRegister"
};
export const getAccessKey = () => { try { return localStorage.getItem(LS.key) || ""; } catch (e) { return ""; } };
export const setAccessKey = (v) => { try { localStorage.setItem(LS.key, v); } catch (e) {} };
export const clearAccessKey = () => { try { localStorage.removeItem(LS.key); } catch (e) {} };
export const getIdentity = () => { try { return localStorage.getItem(LS.me) || ""; } catch (e) { return ""; } };
export const setIdentity = (v) => { try { localStorage.setItem(LS.me, v); } catch (e) {} };

/* Last successfully fetched register — lets the app open read-only when offline */
export const readCache = () => {
  try {
    const r = localStorage.getItem(LS.cache);
    return r ? JSON.parse(r) : null;
  } catch (e) { return null; }
};
export const writeCache = (cases) => {
  try { localStorage.setItem(LS.cache, JSON.stringify({ at: new Date().toISOString(), cases })); } catch (e) {}
};

/* ---- core call ---- */
export class ApiError extends Error {
  constructor(message, code) { super(message); this.code = code || "ERR"; }
}

export async function api(action, payload) {
  if (!scriptConfigured()) throw new ApiError("The app is not yet linked to the department's Google Script. Ask the administrator to set config.js.", "NO_CONFIG");
  let res;
  try {
    res = await fetch(SCRIPT_URL, {
      method: "POST",
      // string body => Content-Type text/plain => no CORS preflight (required for Apps Script)
      body: JSON.stringify({ action, key: getAccessKey(), ...(payload || {}) })
    });
  } catch (e) {
    throw new ApiError("No connection to the server. Check internet and retry.", "NETWORK");
  }
  let j;
  try { j = await res.json(); } catch (e) {
    throw new ApiError("Unexpected reply from the server. If this repeats, ask the administrator to check the Script deployment (Access: Anyone).", "BAD_REPLY");
  }
  if (!j || j.ok !== true) {
    const msg = (j && j.error) || "Request failed";
    throw new ApiError(msg, (j && j.code) || "SERVER");
  }
  return j;
}
