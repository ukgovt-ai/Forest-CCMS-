import React, { useState, useEffect, useMemo, useRef } from "react";
import { api, ApiError, scriptConfigured, getAccessKey, setAccessKey, clearAccessKey, getIdentity, setIdentity, readCache, writeCache } from "./api.js";

/* ================= Constants ================= */

const COURTS = ["High Court", "Supreme Court", "NGT", "CAT", "PST", "District Court", "Labour Court", "Revenue Court", "Lok Adalat", "Arbitrator", "Any Other"];

const CASE_TYPES = ["Writ Petition", "PIL", "Contempt Petition", "SLP", "Original Application (OA)", "Civil Appeal", "Review Petition", "Execution Petition", "Arbitration", "Criminal Case", "Other"];

const NA_TYPES = [
  "Sending Instructions to Court",
  "Counter Affidavit approval from concerned authority",
  "Issuing directions to the concerned for needful",
  "Filing the Counter Affidavit",
  "Briefing the CSC / Standing Counsel",
  "Filing Supplementary Affidavit",
  "Issuing Directions for Compliance of Judgment",
  "Filing Compliance Affidavit",
  "Filing Urgency Application",
  "Other (specify)"
];

const ORDER_TYPES = ["Verbal Directions", "Interim Order", "Adjournment", "Order Reserved", "Final Judgment", "Other"];

const OFFICERS = [
  { group: "Government Level", list: ["ACS/Principal Secretary", "Secretary", "AS F1", "AS F2", "AS F3", "AS F4", "JS", "DS", "US", "SO1", "SO2", "SO3", "SO4", "Senior Consultant", "Consultant"] },
  { group: "PCCF Level", list: ["PCCF (Head of Forest Force)", "PCCF (Van Panchayat)", "PCCF (Wild Life)"] },
  { group: "APCCF Offices", list: ["APCCF (Land Survey Directorate)", "APCCF (RTM)", "APCCF (PFM)", "APCCF (Projects)"] },
  { group: "Chief Conservator of Forests (CCF)", list: ["CCF (Garhwal)", "CCF (Kumaon)", "CCF (Environment)", "CCF (HRD)", "CCF (Eco-Tourism & Publicity)", "CCF (Working Plan)", "CCF (Monitoring, Evaluation & Audit)", "CCF (Administration)", "CCF (Vigilance and Legal)", "CCF (UFTA)", "CCF (Utilisation & NTFP)", "CCF (Forest Fire Protection & Disaster Management)", "CCF (Administration, Wildlife)", "CCF (Van Panchayat & Community Forestry)"] },
  { group: "Conservator of Forests (CF)", list: ["CF (Research)", "CF (Bhagirathi)", "CF (Yamuna)", "CF (Garhwal)", "CF (Shivalik)", "CF (North Kumaun)", "CF (Western)", "CF (South Kumaun)", "CF Land Survey Directorate", "CF FTA", "CF WPO"] },
  { group: "Territorial & Non-territorial Divisions (DFO/DCF)", list: ["DFO Soil, Uttarkashi", "DFO Tehri Dam-I", "DFO Tehri Dam-II", "DFO New Tehri", "DFO Uttarkashi", "DFO Narendra Nagar", "DFO Mussoorie", "DFO Upper Yamuna Barkot", "DFO Tons", "DFO Chakrata", "DFO Garhwal", "DFO Rudraprayag", "DFO Badrinath", "DFO Soil Alaknanda", "DFO Civil & Soyam Pauri", "DFO Dehradun", "DFO Lansdowne", "DFO Haridwar", "DFO Soil Kalsi", "DFO Soil Lansdowne", "DFO Bageshwar", "DFO Almora", "DFO Civil & Soyam Almora", "DFO Pithoragarh", "DFO Champawat", "DFO Haldwani", "DFO Tarai East", "DFO Tarai West", "DFO Tarai Central", "DFO Ramnagar", "DFO Nainital", "DFO Soil Nainital", "DFO Soil Ranikhet", "DFO Soil Ramnagar", "DCF Research", "DCF FTA", "DCF M&E, IT", "DCF PFM"] },
  { group: "Wildlife Directors/CFs", list: ["Director, Rajaji National Park", "Director, Nanda Devi Biosphere Reserve", "Director, Corbett Tiger Reserve"] },
  { group: "Deputy Directors (Wildlife)", list: ["Deputy Director, Rajaji National Park", "Deputy Director, Kalagarh Tiger Reserve Division", "Deputy Director, Corbett National Park", "Deputy Director, Govind Wildlife Sanctuary", "Deputy Director, Gangotri National Park"] },
  { group: "Wildlife DFOs", list: ["DFO Kedarnath Wildlife Division", "DFO Nanda Devi National Park"] }
];

const MAX_FILE_BYTES = 10 * 1024 * 1024; // 10 MB — files are kept in the department's Google Drive

/* ================= Utilities ================= */

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const todayISO = () => {
  const d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
};
const dOf = (iso) => new Date(iso + "T00:00:00");
const daysFrom = (iso) => Math.round((dOf(iso) - dOf(todayISO())) / 86400000);
const fmtD = (iso) => (iso ? dOf(iso).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }) : "\u2014");
const fmtDT = (ts) => new Date(ts).toLocaleString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
const clone = (o) => JSON.parse(JSON.stringify(o));
const rel = (d) => (d === 0 ? "Today" : d === 1 ? "Tomorrow" : d > 1 ? "In " + d + " days" : Math.abs(d) + "d ago");

const courtLabel = (c) => (c.court === "Any Other" ? c.courtOther || "Other Court" : c.court);
const typeLabel = (c) => (c.caseType === "Other" ? c.caseTypeOther || "Other" : c.caseType);
const titleOf = (c) => {
  const p = (c.petitioners || "").split(/\n|,/)[0].trim() || "Petitioner";
  const r = (c.respondents && c.respondents[0] && c.respondents[0].trim()) || "State of Uttarakhand & Ors.";
  return p + " vs " + r;
};
const actionLabel = (a) => (a.type.startsWith("Other") ? a.otherText || "Other action" : a.type);
const caseStats = (c) => {
  const acts = c.actions || [];
  const pend = acts.filter((a) => a.currentStatus !== "Completed");
  const od = pend.filter((a) => a.dueDate && daysFrom(a.dueDate) < 0);
  return { total: acts.length, pend: pend.length, od: od.length };
};



/* ================= UI atoms ================= */

const TONES = {
  green: ["#e6f0e6", "#1f5130"],
  amber: ["#fbeed2", "#8a5a08"],
  red: ["#f9e3e3", "#a11a1a"],
  gray: ["#eceadf", "#5c6156"],
  blue: ["#e3ecf3", "#2c4d6e"],
  orange: ["#fcead9", "#b4530a"]
};
const Badge = ({ t = "gray", children }) => {
  const pair = TONES[t] || TONES.gray;
  return (
    <span style={{ background: pair[0], color: pair[1], borderRadius: 999, padding: "2px 9px", fontSize: 11, fontWeight: 700, whiteSpace: "nowrap", display: "inline-block", lineHeight: "16px" }}>
      {children}
    </span>
  );
};

const statusTone = (s) => (s === "Completed" ? "green" : s === "Under Process" ? "amber" : s === "Not Completed" ? "red" : "gray");
const caseStatusTone = (s) => (s === "Active" ? "green" : s === "Disposed" ? "blue" : "gray");

const Field = ({ label, req, children, span }) => (
  <div className={span ? "md:col-span-2" : ""}>
    <span className="lbl">
      {label}
      {req && <span style={{ color: "#a11a1a" }}> *</span>}
    </span>
    {children}
  </div>
);

const OfficerSelect = ({ value, onChange, dark }) => (
  <select className="inp" style={dark ? { background: "#31352e", color: "#f0eee4", borderColor: "#4a4f45", fontSize: 12, padding: "6px 8px" } : undefined} value={value} onChange={(e) => onChange(e.target.value)}>
    <option value="">{dark ? "\u2014 select your name \u2014" : "\u2014 select officer \u2014"}</option>
    {OFFICERS.map((g) => (
      <optgroup key={g.group} label={g.group}>
        {g.list.map((o) => (
          <option key={o} value={o}>
            {o}
          </option>
        ))}
      </optgroup>
    ))}
  </select>
);

const Sec = ({ title, right, children, tone }) => (
  <div className="card" style={{ padding: 14 }}>
    <div className="flex items-center justify-between mb-2 gap-2">
      <div className="serif" style={{ fontSize: 15.5, fontWeight: 700, color: tone || "#232620" }}>{title}</div>
      {right}
    </div>
    {children}
  </div>
);

const Empty = ({ children }) => <div style={{ fontSize: 13, color: "#7a7f70", padding: "6px 2px" }}>{children}</div>;

/* ================= Necessary Actions editor ================= */

function NAEditor({ sel, setSel }) {
  const toggle = (t) => {
    const n = { ...sel };
    if (n[t]) delete n[t];
    else n[t] = { officer: "", dueDate: "", otherText: "" };
    setSel(n);
  };
  const upd = (t, k, v) => setSel({ ...sel, [t]: { ...sel[t], [k]: v } });
  return (
    <div className="grid gap-2">
      {NA_TYPES.map((t) => {
        const on = !!sel[t];
        return (
          <div key={t} style={{ border: "1px solid " + (on ? "#2d6a4f" : "#e0dbc9"), background: on ? "#f3f8f3" : "#fff", borderRadius: 10, padding: "10px 12px" }}>
            <label style={{ display: "flex", gap: 10, alignItems: "flex-start", cursor: "pointer", fontSize: 13.5, fontWeight: 600 }}>
              <input type="checkbox" checked={on} onChange={() => toggle(t)} style={{ marginTop: 2, accentColor: "#1f5130", width: 15, height: 15 }} />
              <span>{t}</span>
            </label>
            {on && (
              <div className="grid md:grid-cols-2 gap-2 mt-2" style={{ paddingLeft: 25 }}>
                {t.startsWith("Other") && (
                  <Field label="Specify action" req span>
                    <input className="inp" value={sel[t].otherText} onChange={(e) => upd(t, "otherText", e.target.value)} placeholder="Describe the action required" />
                  </Field>
                )}
                <Field label="Responsible officer" req>
                  <OfficerSelect value={sel[t].officer} onChange={(v) => upd(t, "officer", v)} />
                </Field>
                <Field label="Due date" req>
                  <input type="date" className="inp" value={sel[t].dueDate} onChange={(e) => upd(t, "dueDate", e.target.value)} />
                </Field>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

const naComplete = (sel) => Object.entries(sel).every(([t, v]) => v.officer && v.dueDate && (!t.startsWith("Other") || v.otherText.trim()));
const naBuild = (sel, stageKind, hearingId, by) =>
  Object.entries(sel).map(([t, v]) => ({
    id: uid(),
    type: t,
    otherText: v.otherText || "",
    officer: v.officer,
    dueDate: v.dueDate,
    stageKind,
    hearingId: hearingId || null,
    createdBy: by,
    createdAt: new Date().toISOString(),
    currentStatus: "Pending",
    completedOn: null,
    updates: []
  }));

/* ================= Case form (new / edit basics) ================= */

function CaseForm({ initial, me, withNA, title, onSave, onCancel }) {
  const [court, setCourt] = useState(initial?.court || "High Court");
  const [courtOther, setCourtOther] = useState(initial?.courtOther || "");
  const [caseNumber, setCaseNumber] = useState(initial?.caseNumber || "");
  const [caseType, setCaseType] = useState(initial?.caseType || "Writ Petition");
  const [caseTypeOther, setCaseTypeOther] = useState(initial?.caseTypeOther || "");
  const [petitioners, setPetitioners] = useState(initial?.petitioners || "");
  const [respondents, setRespondents] = useState(initial?.respondents?.length ? initial.respondents : [""]);
  const [gist, setGist] = useState(initial?.gist || "");
  const [noticeDate, setNoticeDate] = useState(initial?.noticeDate || todayISO());
  const [standingCounsel, setStandingCounsel] = useState(initial?.standingCounsel || "");
  const [nodalOfficer, setNodalOfficer] = useState(initial?.nodalOfficer || "");
  const [nextDate, setNextDate] = useState(initial?.nextHearingDate || "");
  const [notFixed, setNotFixed] = useState(initial ? !!initial.dateNotFixed && !initial.nextHearingDate : false);
  const [sel, setSel] = useState({});
  const [err, setErr] = useState("");

  const setResp = (i, v) => setRespondents(respondents.map((r, j) => (j === i ? v : r)));
  const addResp = () => setRespondents([...respondents, ""]);
  const rmResp = (i) => setRespondents(respondents.filter((_, j) => j !== i));

  const submit = () => {
    if (!caseNumber.trim()) return setErr("Case number is required.");
    if (court === "Any Other" && !courtOther.trim()) return setErr("Please specify the court / forum.");
    if (caseType === "Other" && !caseTypeOther.trim()) return setErr("Please specify the nature of the case.");
    if (!petitioners.trim()) return setErr("Petitioner details are required.");
    if (!notFixed && !nextDate) return setErr("Enter the next date of listing, or tick \u201cdate not fixed yet\u201d.");
    if (withNA && Object.keys(sel).length > 0 && !naComplete(sel)) return setErr("Each selected necessary action needs a responsible officer and a due date.");
    const data = {
      court, courtOther: courtOther.trim(), caseNumber: caseNumber.trim(),
      caseType, caseTypeOther: caseTypeOther.trim(),
      petitioners: petitioners.trim(),
      respondents: respondents.map((r) => r.trim()).filter(Boolean),
      gist: gist.trim(), noticeDate, standingCounsel: standingCounsel.trim(), nodalOfficer,
      nextHearingDate: notFixed ? null : nextDate,
      dateNotFixed: notFixed
    };
    const actions = withNA ? naBuild(sel, "notice", null, me) : null;
    onSave(data, actions);
  };

  return (
    <div className="grid gap-3">
      <Sec title={title}>
        <div className="grid md:grid-cols-2 gap-3">
          <Field label="Court / forum" req>
            <select className="inp" value={court} onChange={(e) => setCourt(e.target.value)}>
              {COURTS.map((c) => <option key={c}>{c}</option>)}
            </select>
          </Field>
          {court === "Any Other" && (
            <Field label="Specify court / forum" req>
              <input className="inp" value={courtOther} onChange={(e) => setCourtOther(e.target.value)} placeholder="e.g. Commercial Court, Dehradun" />
            </Field>
          )}
          <Field label="Case number" req>
            <input className="inp" value={caseNumber} onChange={(e) => setCaseNumber(e.target.value)} placeholder="e.g. WPPIL 45/2026" />
          </Field>
          <Field label="Nature of case" req>
            <select className="inp" value={caseType} onChange={(e) => setCaseType(e.target.value)}>
              {CASE_TYPES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </Field>
          {caseType === "Other" && (
            <Field label="Specify nature of case" req>
              <input className="inp" value={caseTypeOther} onChange={(e) => setCaseTypeOther(e.target.value)} />
            </Field>
          )}
          <Field label="Petitioner details" req span>
            <textarea className="inp" rows={2} value={petitioners} onChange={(e) => setPetitioners(e.target.value)} placeholder="Name(s) and particulars of petitioner(s)" />
          </Field>
          <div className="md:col-span-2">
            <span className="lbl">Respondent details</span>
            <div className="grid gap-2">
              {respondents.map((r, i) => (
                <div key={i} className="flex gap-2 items-center">
                  <span style={{ fontSize: 12, color: "#6b7061", whiteSpace: "nowrap", width: 88 }}>Respondent {i + 1}</span>
                  <input className="inp" value={r} onChange={(e) => setResp(i, e.target.value)} placeholder="Name / designation" />
                  {respondents.length > 1 && (
                    <button className="btn" style={{ padding: "6px 10px" }} onClick={() => rmResp(i)} title="Remove">&#10005;</button>
                  )}
                </div>
              ))}
            </div>
            <button className="btn mt-2" onClick={addResp}>+ Add respondent</button>
          </div>
          <Field label="Gist of grievance / demand" span>
            <textarea className="inp" rows={3} value={gist} onChange={(e) => setGist(e.target.value)} placeholder="Brief substance of the petition" />
          </Field>
          <Field label="Date of notice received">
            <input type="date" className="inp" value={noticeDate} onChange={(e) => setNoticeDate(e.target.value)} />
          </Field>
          <Field label="Standing Counsel who marked the letter">
            <input className="inp" value={standingCounsel} onChange={(e) => setStandingCounsel(e.target.value)} placeholder="Name of CSC / Standing Counsel" />
          </Field>
          <Field label="Case forwarded to (nodal / dealing officer)">
            <OfficerSelect value={nodalOfficer} onChange={setNodalOfficer} />
          </Field>
          <div>
            <span className="lbl">Next date of listing</span>
            <input type="date" className="inp" value={nextDate} disabled={notFixed} onChange={(e) => setNextDate(e.target.value)} />
            <label style={{ display: "flex", gap: 7, alignItems: "center", fontSize: 12.5, marginTop: 6, cursor: "pointer" }}>
              <input type="checkbox" checked={notFixed} onChange={(e) => { setNotFixed(e.target.checked); if (e.target.checked) setNextDate(""); }} style={{ accentColor: "#1f5130" }} />
              Date not fixed yet
            </label>
          </div>
        </div>
      </Sec>

      {withNA && (
        <Sec title="Necessary Actions (NA) on receipt of notice" right={<span style={{ fontSize: 11.5, color: "#7a7f70" }}>tick all that apply</span>}>
          <NAEditor sel={sel} setSel={setSel} />
        </Sec>
      )}

      {err && <div style={{ background: "#f9e3e3", color: "#a11a1a", borderRadius: 8, padding: "8px 12px", fontSize: 13, fontWeight: 600 }}>{err}</div>}
      <div className="flex gap-2 justify-end noprint">
        <button className="btn" onClick={onCancel}>Cancel</button>
        <button className="btn btnP" onClick={submit}>{withNA ? "Save case" : "Save changes"}</button>
      </div>
    </div>
  );
}

/* ================= Action card & updates ================= */

function UpdateForm({ onSave, onCancel }) {
  const [status, setStatus] = useState("Under Process");
  const [date, setDate] = useState(todayISO());
  const [remarks, setRemarks] = useState("");
  const [err, setErr] = useState("");
  return (
    <div style={{ background: "#f7f5ea", border: "1px solid #e0dbc9", borderRadius: 10, padding: 12 }} className="mt-2 grid gap-2">
      <div className="grid md:grid-cols-2 gap-2">
        <Field label="Status" req>
          <select className="inp" value={status} onChange={(e) => setStatus(e.target.value)}>
            {["Completed", "Under Process", "Not Completed"].map((s) => <option key={s}>{s}</option>)}
          </select>
        </Field>
        <Field label={status === "Completed" ? "Date of completion" : "Date"} req>
          <input type="date" className="inp" value={date} onChange={(e) => setDate(e.target.value)} />
        </Field>
      </div>
      <Field label="Remarks / brief description" req>
        <textarea className="inp" rows={2} value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="What was done / present position" />
      </Field>
      {err && <div style={{ color: "#a11a1a", fontSize: 12.5, fontWeight: 600 }}>{err}</div>}
      <div className="flex gap-2 justify-end">
        <button className="btn" onClick={onCancel}>Cancel</button>
        <button className="btn btnP" onClick={() => {
          if (!date) return setErr("Date is required.");
          if (!remarks.trim()) return setErr("Please add brief remarks.");
          onSave({ status, date, remarks: remarks.trim() });
        }}>Save update</button>
      </div>
    </div>
  );
}

function ActionCard({ c, a, me, onAddUpdate, onDelete }) {
  const [open, setOpen] = useState(false);
  const od = a.currentStatus !== "Completed" && a.dueDate && daysFrom(a.dueDate) < 0;
  const canUpdate = me && (me === a.officer || me === c.createdBy);
  return (
    <div className="card" style={{ padding: "11px 13px", borderLeft: od ? "4px solid #d97706" : "4px solid transparent" }}>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div style={{ fontSize: 13.5, fontWeight: 700, flex: 1, minWidth: 180 }}>{actionLabel(a)}</div>
        <div className="flex gap-1 flex-wrap items-center">
          <Badge t={statusTone(a.currentStatus)}>{a.currentStatus}</Badge>
          {od && <Badge t="red">Overdue {Math.abs(daysFrom(a.dueDate))}d</Badge>}
          {a.updates.length === 0 && me === a.createdBy && (
            <button className="btn" style={{ padding: "2px 8px", fontSize: 11 }} title="Delete this action (no updates yet)" onClick={onDelete}>&#10005;</button>
          )}
        </div>
      </div>
      <div style={{ fontSize: 12.5, color: "#5c6156", marginTop: 4 }}>
        <b style={{ color: "#232620" }}>{a.officer}</b> &nbsp;&bull;&nbsp; Due: <b style={{ color: od ? "#a11a1a" : "#232620" }}>{fmtD(a.dueDate)}</b>
        {a.currentStatus === "Completed" && a.completedOn && <span> &nbsp;&bull;&nbsp; Completed on {fmtD(a.completedOn)}</span>}
      </div>
      {a.updates.length > 0 && (
        <div className="grid gap-1 mt-2" style={{ borderTop: "1px dashed #ded8c4", paddingTop: 8 }}>
          {a.updates.map((u) => (
            <div key={u.id} style={{ fontSize: 12.5 }}>
              <Badge t={statusTone(u.status)}>{u.status}</Badge>
              <span style={{ color: "#5c6156" }}> &nbsp;{fmtD(u.date)} &mdash; </span>
              {u.remarks}
              <span style={{ color: "#8a8f80" }}> &nbsp;({u.by}, {fmtDT(u.at)})</span>
            </div>
          ))}
        </div>
      )}
      <div className="mt-2 noprint">
        {open ? (
          <UpdateForm onCancel={() => setOpen(false)} onSave={(u) => { onAddUpdate(u); setOpen(false); }} />
        ) : (
          <button className="btn" disabled={!canUpdate} title={canUpdate ? "" : "Only the assigned officer (or the case creator) can update this action"} style={{ opacity: canUpdate ? 1 : 0.45 }} onClick={() => setOpen(true)}>
            + Add update
          </button>
        )}
      </div>
      <div style={{ fontSize: 10.5, color: "#9b9f90", marginTop: 6 }}>Entered by {a.createdBy}, {fmtDT(a.createdAt)} &middot; updates are append-only</div>
    </div>
  );
}

/* ================= Hearing form ================= */

function HearingForm({ onSave, onCancel }) {
  const [date, setDate] = useState(todayISO());
  const [orderType, setOrderType] = useState("Verbal Directions");
  const [directions, setDirections] = useState("");
  const [nextDate, setNextDate] = useState("");
  const [notFixed, setNotFixed] = useState(false);
  const [disposed, setDisposed] = useState(false);
  const [err, setErr] = useState("");
  return (
    <div style={{ background: "#f7f5ea", border: "1px solid #e0dbc9", borderRadius: 10, padding: 12 }} className="grid gap-2">
      <div className="grid md:grid-cols-2 gap-2">
        <Field label="Date of hearing" req>
          <input type="date" className="inp" value={date} onChange={(e) => setDate(e.target.value)} />
        </Field>
        <Field label="Nature of order" req>
          <select className="inp" value={orderType} onChange={(e) => setOrderType(e.target.value)}>
            {ORDER_TYPES.map((o) => <option key={o}>{o}</option>)}
          </select>
        </Field>
      </div>
      <Field label="Interim judgment / verbal directions of the Court" req>
        <textarea className="inp" rows={3} value={directions} onChange={(e) => setDirections(e.target.value)} placeholder="Substance of the order / directions passed" />
      </Field>
      <div>
        <span className="lbl">Next date of hearing</span>
        <input type="date" className="inp" value={nextDate} disabled={notFixed} onChange={(e) => setNextDate(e.target.value)} />
        <label style={{ display: "flex", gap: 7, alignItems: "center", fontSize: 12.5, marginTop: 6, cursor: "pointer" }}>
          <input type="checkbox" checked={notFixed} onChange={(e) => { setNotFixed(e.target.checked); if (e.target.checked) setNextDate(""); }} style={{ accentColor: "#1f5130" }} />
          Date not fixed yet
        </label>
      </div>
      <label style={{ display: "flex", gap: 7, alignItems: "center", fontSize: 12.5, cursor: "pointer" }}>
        <input type="checkbox" checked={disposed} onChange={(e) => setDisposed(e.target.checked)} style={{ accentColor: "#1f5130" }} />
        Case finally disposed (judgment delivered) &mdash; mark case as Disposed
      </label>
      {err && <div style={{ color: "#a11a1a", fontSize: 12.5, fontWeight: 600 }}>{err}</div>}
      <div className="flex gap-2 justify-end">
        <button className="btn" onClick={onCancel}>Cancel</button>
        <button className="btn btnP" onClick={() => {
          if (!date) return setErr("Hearing date is required.");
          if (!directions.trim()) return setErr("Please record the directions / order.");
          if (!notFixed && !nextDate && !disposed) return setErr("Enter the next date, or tick \u201cdate not fixed yet\u201d.");
          onSave({ date, orderType, directions: directions.trim(), nextDate: notFixed ? null : nextDate || null, notFixed: notFixed || (!nextDate && !disposed) }, disposed);
        }}>Save hearing</button>
      </div>
    </div>
  );
}

/* ================= Add-NA panel (later batches) ================= */

function AddNAPanel({ c, me, defaultStage, onSave, onCancel }) {
  const hearAsc = [...(c.hearings || [])].sort((a, b) => (a.date < b.date ? -1 : 1));
  const stageOpts = [
    { v: "notice", l: "On receipt of notice" },
    ...hearAsc.map((h) => ({ v: "h:" + h.id, l: "After hearing dt. " + fmtD(h.date) })),
    { v: "compliance", l: "Post-judgment / compliance" }
  ];
  const [stage, setStage] = useState(defaultStage || (hearAsc.length ? "h:" + hearAsc[hearAsc.length - 1].id : "notice"));
  const [sel, setSel] = useState({});
  const [err, setErr] = useState("");
  return (
    <div style={{ background: "#f7f5ea", border: "1px solid #e0dbc9", borderRadius: 10, padding: 12 }} className="grid gap-2">
      <Field label="These actions arise from" req>
        <select className="inp" value={stage} onChange={(e) => setStage(e.target.value)}>
          {stageOpts.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
        </select>
      </Field>
      <NAEditor sel={sel} setSel={setSel} />
      {err && <div style={{ color: "#a11a1a", fontSize: 12.5, fontWeight: 600 }}>{err}</div>}
      <div className="flex gap-2 justify-end">
        <button className="btn" onClick={onCancel}>Cancel</button>
        <button className="btn btnP" onClick={() => {
          if (Object.keys(sel).length === 0) return setErr("Tick at least one necessary action.");
          if (!naComplete(sel)) return setErr("Each selected action needs a responsible officer and a due date.");
          const kind = stage === "notice" ? "notice" : stage === "compliance" ? "compliance" : "hearing";
          const hid = kind === "hearing" ? stage.slice(2) : null;
          onSave(naBuild(sel, kind, hid, me));
        }}>Save actions</button>
      </div>
    </div>
  );
}

/* ================= Files ================= */

function FilesSection({ c, me, onUpload, onDownload, onDeleteFile }) {
  const ref = useRef(null);
  const files = c.files || [];
  return (
    <Sec title="Judgment / order copies" right={
      <span className="noprint">
        <input ref={ref} type="file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" style={{ display: "none" }} onChange={(e) => { const f = e.target.files && e.target.files[0]; if (f) onUpload(f); e.target.value = ""; }} />
        <button className="btn" onClick={() => ref.current && ref.current.click()}>&#8613; Upload (max 10 MB)</button>
      </span>
    }>
      {files.length === 0 ? (
        <Empty>No copies uploaded yet. PDF or image, up to 10 MB per file &mdash; saved in the department Google Drive.</Empty>
      ) : (
        <div className="grid gap-2">
          {files.map((f) => (
            <div key={f.id} className="flex flex-wrap items-center justify-between gap-2" style={{ border: "1px solid #e0dbc9", borderRadius: 8, padding: "7px 10px", fontSize: 12.5 }}>
              <div style={{ minWidth: 0 }}>
                <b style={{ wordBreak: "break-all" }}>{f.name}</b>
                <div style={{ color: "#8a8f80", fontSize: 11 }}>{Math.round(f.size / 1024)} KB &middot; {f.by} &middot; {fmtDT(f.at)}</div>
              </div>
              <div className="flex gap-1 noprint">
                <button className="btn" style={{ padding: "4px 10px", fontSize: 12 }} onClick={() => onDownload(f)}>Download</button>
                {(me === f.by || me === c.createdBy) && (
                  <button className="btn btnD" style={{ padding: "4px 10px", fontSize: 12 }} onClick={() => onDeleteFile(f)}>Delete</button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </Sec>
  );
}

/* ================= Case detail ================= */

function CaseDetail({ c, me, H }) {
  const [showHearing, setShowHearing] = useState(false);
  const [showNA, setShowNA] = useState(false);
  const [naStage, setNaStage] = useState(null);
  const st = caseStats(c);
  const hearAsc = [...(c.hearings || [])].sort((a, b) => (a.date < b.date ? -1 : 1));
  const hearDesc = [...hearAsc].reverse();
  const stages = [
    { k: "notice", hid: null, label: "On receipt of notice" },
    ...hearAsc.map((h) => ({ k: "hearing", hid: h.id, label: "After hearing dt. " + fmtD(h.date) })),
    { k: "compliance", hid: null, label: "Post-judgment / compliance" }
  ];
  const actsFor = (s) => (c.actions || []).filter((a) => (s.k === "hearing" ? a.hearingId === s.hid : a.stageKind === s.k));
  const hearingPassed = c.status === "Active" && c.nextHearingDate && daysFrom(c.nextHearingDate) < 0;

  return (
    <div className="grid gap-3">
      <button className="btn noprint" style={{ justifySelf: "start" }} onClick={() => H.setView("list")}>&larr; Case register</button>

      <div className="card" style={{ padding: 16, borderTop: "3px solid #d97706" }}>
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <div className="serif" style={{ fontSize: 21, fontWeight: 700, lineHeight: 1.15 }}>{c.caseNumber}</div>
            <div style={{ fontSize: 13.5, color: "#4a4f43", marginTop: 3 }}>{titleOf(c)}</div>
            <div className="flex gap-1 flex-wrap mt-2">
              <Badge t="blue">{courtLabel(c)}</Badge>
              <Badge t="gray">{typeLabel(c)}</Badge>
              <Badge t={caseStatusTone(c.status)}>{c.status}</Badge>
              {st.od > 0 && <Badge t="red">{st.od} overdue</Badge>}
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <span className="lbl" style={{ marginBottom: 2 }}>Next date of hearing</span>
            {c.nextHearingDate ? (
              <div>
                <div className="serif" style={{ fontSize: 17, fontWeight: 700, color: daysFrom(c.nextHearingDate) <= 3 && daysFrom(c.nextHearingDate) >= 0 ? "#a11a1a" : "#1f5130" }}>{fmtD(c.nextHearingDate)}</div>
                <Badge t={daysFrom(c.nextHearingDate) < 0 ? "red" : daysFrom(c.nextHearingDate) <= 7 ? "amber" : "green"}>{rel(daysFrom(c.nextHearingDate))}</Badge>
              </div>
            ) : (
              <Badge t="amber">Date not fixed yet</Badge>
            )}
            {me === c.createdBy && (
              <div className="mt-2 noprint">
                <select className="inp" style={{ width: 130, fontSize: 12, padding: "5px 8px" }} value={c.status} onChange={(e) => H.patchCase(c.id, { status: e.target.value })}>
                  {["Active", "Disposed", "Closed"].map((s) => <option key={s}>{s}</option>)}
                </select>
              </div>
            )}
          </div>
        </div>
        {(st.od > 0 || hearingPassed) && (
          <div style={{ marginTop: 12, background: "#fbeed2", border: "1px solid #ecd6a4", borderRadius: 8, padding: "8px 12px", fontSize: 12.5, fontWeight: 600, color: "#7a4d06" }}>
            {st.od > 0 && <div>&#9888; {st.od} necessary action{st.od > 1 ? "s are" : " is"} pending beyond due date.</div>}
            {hearingPassed && <div>&#9888; The listed hearing date has passed &mdash; record the outcome and the next date below.</div>}
          </div>
        )}
      </div>

      <Sec title="Case particulars">
        <div className="grid md:grid-cols-2 gap-x-6 gap-y-3" style={{ fontSize: 13 }}>
          <div><span className="lbl">Petitioner(s)</span><div style={{ whiteSpace: "pre-wrap" }}>{c.petitioners || "\u2014"}</div></div>
          <div>
            <span className="lbl">Respondents</span>
            {(c.respondents || []).length ? (
              <ol style={{ margin: 0, paddingLeft: 18 }}>{c.respondents.map((r, i) => <li key={i}>{r}</li>)}</ol>
            ) : "\u2014"}
          </div>
          <div className="md:col-span-2"><span className="lbl">Gist of grievance / demand</span><div style={{ whiteSpace: "pre-wrap" }}>{c.gist || "\u2014"}</div></div>
          <div><span className="lbl">Notice received on</span>{fmtD(c.noticeDate)}</div>
          <div><span className="lbl">Standing Counsel (marked by)</span>{c.standingCounsel || "\u2014"}</div>
          <div><span className="lbl">Forwarded to (nodal officer)</span>{c.nodalOfficer || "\u2014"}</div>
          <div><span className="lbl">Entered by</span>{c.createdBy}, {fmtDT(c.createdAt)}</div>
        </div>
        {me === c.createdBy && (
          <div className="flex gap-2 mt-3 noprint">
            <button className="btn" onClick={() => H.setView("edit")}>Edit particulars</button>
            <button className="btn btnD" onClick={() => H.deleteCase(c.id)}>Delete case</button>
          </div>
        )}
        {me !== c.createdBy && <div style={{ fontSize: 11, color: "#9b9f90", marginTop: 8 }}>Only the officer who entered the case ({c.createdBy}) can edit these particulars. Others add hearings, actions and updates below.</div>}
      </Sec>

      <FilesSection c={c} me={me} onUpload={(f) => H.uploadFile(c.id, f)} onDownload={(f) => H.downloadFile(c.id, f)} onDeleteFile={(f) => H.deleteFile(c.id, f)} />

      <div className="flex gap-2 flex-wrap noprint">
        <button className="btn btnP" onClick={() => { setShowHearing(!showHearing); setShowNA(false); }}>&#9878; Record hearing outcome</button>
        <button className="btn" onClick={() => { setShowNA(!showNA); setShowHearing(false); setNaStage(null); }}>+ Add necessary actions</button>
      </div>

      {showHearing && (
        <HearingForm onCancel={() => setShowHearing(false)} onSave={async (h, disposed) => {
          const hid = await H.addHearing(c.id, h, disposed);
          setShowHearing(false);
          if (hid && !disposed) { setNaStage("h:" + hid); setShowNA(true); }
          if (hid && disposed) { setNaStage("compliance"); setShowNA(true); }
        }} />
      )}
      {showNA && (
        <AddNAPanel c={c} me={me} defaultStage={naStage} onCancel={() => setShowNA(false)} onSave={async (acts) => { await H.addActions(c.id, acts); setShowNA(false); }} />
      )}

      <div>
        <div className="serif" style={{ fontSize: 16.5, fontWeight: 700, margin: "4px 0 8px" }}>Necessary Actions &amp; follow-up</div>
        {(c.actions || []).length === 0 ? (
          <div className="card" style={{ padding: 14 }}><Empty>No necessary actions recorded yet. Use &ldquo;+ Add necessary actions&rdquo; above.</Empty></div>
        ) : (
          <div className="grid gap-3">
            {stages.map((s, i) => {
              const acts = actsFor(s);
              if (!acts.length) return null;
              return (
                <div key={i}>
                  <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: ".07em", textTransform: "uppercase", color: "#7a7f70", margin: "2px 0 6px", borderBottom: "1px solid #ded8c4", paddingBottom: 4 }}>{s.label}</div>
                  <div className="grid gap-2">
                    {acts.map((a) => (
                      <ActionCard key={a.id} c={c} a={a} me={me}
                        onAddUpdate={(u) => H.addUpdate(c.id, a.id, u)}
                        onDelete={() => H.deleteAction(c.id, a.id)} />
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div>
        <div className="serif" style={{ fontSize: 16.5, fontWeight: 700, margin: "4px 0 8px" }}>Court proceedings</div>
        {hearDesc.length === 0 ? (
          <div className="card" style={{ padding: 14 }}><Empty>No hearing recorded yet. After every hearing, record the order and the next date here.</Empty></div>
        ) : (
          <div className="grid gap-2">
            {hearDesc.map((h) => (
              <div key={h.id} className="card" style={{ padding: "11px 13px" }}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="serif" style={{ fontWeight: 700, fontSize: 14.5 }}>{fmtD(h.date)}</div>
                  <div className="flex gap-1"><Badge t="orange">{h.orderType}</Badge></div>
                </div>
                <div style={{ fontSize: 13, marginTop: 6, whiteSpace: "pre-wrap" }}>{h.directions}</div>
                <div style={{ fontSize: 12, color: "#5c6156", marginTop: 6 }}>
                  Next date: <b>{h.notFixed || !h.nextDate ? "not fixed yet" : fmtD(h.nextDate)}</b>
                  <span style={{ color: "#9b9f90" }}> &nbsp;&middot; recorded by {h.by}, {fmtDT(h.at)}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ================= Dashboard ================= */

const Stat = ({ n, l, tone }) => (
  <div className="card" style={{ padding: "10px 14px", flex: "1 1 100px" }}>
    <div className="serif" style={{ fontSize: 26, fontWeight: 700, color: tone || "#1f5130", lineHeight: 1 }}>{n}</div>
    <div style={{ fontSize: 11, color: "#6b7061", fontWeight: 700, marginTop: 4, letterSpacing: ".02em" }}>{l}</div>
  </div>
);

function Dashboard({ cases, openCase, goNew }) {
  const active = cases.filter((c) => c.status !== "Closed");
  const allActs = cases.flatMap((c) => (c.actions || []).map((a) => ({ a, c })));
  const pend = allActs.filter((x) => x.a.currentStatus !== "Completed" && x.c.status !== "Closed");
  const overdue = pend.filter((x) => x.a.dueDate && daysFrom(x.a.dueDate) < 0).sort((p, q) => daysFrom(p.a.dueDate) - daysFrom(q.a.dueDate));
  const dueSoon = pend.filter((x) => x.a.dueDate && daysFrom(x.a.dueDate) >= 0 && daysFrom(x.a.dueDate) <= 7).sort((p, q) => daysFrom(p.a.dueDate) - daysFrom(q.a.dueDate));
  const withNext = active.filter((c) => c.status === "Active" && c.nextHearingDate);
  const upcoming = withNext.filter((c) => daysFrom(c.nextHearingDate) >= 0).sort((p, q) => daysFrom(p.nextHearingDate) - daysFrom(q.nextHearingDate));
  const passed = withNext.filter((c) => daysFrom(c.nextHearingDate) < 0);
  const notFixed = active.filter((c) => c.status === "Active" && !c.nextHearingDate);
  const week = upcoming.filter((c) => daysFrom(c.nextHearingDate) <= 7);

  if (cases.length === 0) {
    return (
      <div className="card" style={{ padding: 24, textAlign: "center" }}>
        <div className="serif" style={{ fontSize: 20, fontWeight: 700 }}>The register is empty</div>
        <div style={{ fontSize: 13.5, color: "#5c6156", margin: "8px 0 14px" }}>Enter a case as soon as a notice is received from the Court. All officers using this app see the same register.</div>
        <button className="btn btnP noprint" onClick={goNew}>+ Enter first case</button>
      </div>
    );
  }

  const Row = ({ onClick, children }) => (
    <div className="row" style={{ padding: "8px 10px", borderRadius: 8, display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center", justifyContent: "space-between" }} onClick={onClick}>
      {children}
    </div>
  );

  return (
    <div className="grid gap-3">
      <div className="flex gap-2 flex-wrap">
        <Stat n={active.length} l="ACTIVE CASES" />
        <Stat n={week.length} l="HEARINGS \u2264 7 DAYS" tone={week.length ? "#b4530a" : "#1f5130"} />
        <Stat n={overdue.length} l="OVERDUE ACTIONS" tone={overdue.length ? "#a11a1a" : "#1f5130"} />
        <Stat n={pend.length} l="PENDING ACTIONS" />
        <Stat n={notFixed.length} l="DATE NOT FIXED" tone={notFixed.length ? "#8a5a08" : "#1f5130"} />
      </div>

      {overdue.length > 0 && (
        <Sec title={"\u26A0 Necessary actions pending beyond due date (" + overdue.length + ")"} tone="#a11a1a">
          <div className="grid gap-1">
            {overdue.slice(0, 10).map(({ a, c }) => (
              <Row key={a.id} onClick={() => openCase(c.id)}>
                <div style={{ fontSize: 13, minWidth: 0 }}>
                  <b>{c.caseNumber}</b> &middot; {actionLabel(a)}
                  <div style={{ fontSize: 11.5, color: "#5c6156" }}>{a.officer} &middot; due {fmtD(a.dueDate)}</div>
                </div>
                <Badge t="red">{Math.abs(daysFrom(a.dueDate))}d overdue</Badge>
              </Row>
            ))}
            {overdue.length > 10 && <Empty>+ {overdue.length - 10} more &mdash; see the case register.</Empty>}
          </div>
        </Sec>
      )}

      {passed.length > 0 && (
        <Sec title="Hearing date passed \u2014 outcome not yet recorded" tone="#8a5a08">
          <div className="grid gap-1">
            {passed.map((c) => (
              <Row key={c.id} onClick={() => openCase(c.id)}>
                <div style={{ fontSize: 13 }}><b>{c.caseNumber}</b> &middot; {courtLabel(c)}</div>
                <Badge t="amber">was listed {fmtD(c.nextHearingDate)}</Badge>
              </Row>
            ))}
          </div>
        </Sec>
      )}

      <Sec title="Upcoming hearings">
        {upcoming.length === 0 ? <Empty>No hearing dates on record.</Empty> : (
          <div className="grid gap-1">
            {upcoming.slice(0, 10).map((c) => {
              const d = daysFrom(c.nextHearingDate);
              return (
                <Row key={c.id} onClick={() => openCase(c.id)}>
                  <div style={{ fontSize: 13, minWidth: 0 }}>
                    <b>{fmtD(c.nextHearingDate)}</b> &middot; {c.caseNumber}
                    <div style={{ fontSize: 11.5, color: "#5c6156" }}>{courtLabel(c)} &middot; {titleOf(c)}</div>
                  </div>
                  <Badge t={d <= 1 ? "red" : d <= 7 ? "amber" : "gray"}>{rel(d)}</Badge>
                </Row>
              );
            })}
          </div>
        )}
      </Sec>

      {dueSoon.length > 0 && (
        <Sec title="Actions falling due within 7 days">
          <div className="grid gap-1">
            {dueSoon.slice(0, 10).map(({ a, c }) => (
              <Row key={a.id} onClick={() => openCase(c.id)}>
                <div style={{ fontSize: 13, minWidth: 0 }}>
                  <b>{c.caseNumber}</b> &middot; {actionLabel(a)}
                  <div style={{ fontSize: 11.5, color: "#5c6156" }}>{a.officer}</div>
                </div>
                <Badge t="amber">due {rel(daysFrom(a.dueDate)).toLowerCase()}</Badge>
              </Row>
            ))}
          </div>
        </Sec>
      )}

      {notFixed.length > 0 && (
        <Sec title="Next date not fixed yet">
          <div className="grid gap-1">
            {notFixed.map((c) => (
              <Row key={c.id} onClick={() => openCase(c.id)}>
                <div style={{ fontSize: 13 }}><b>{c.caseNumber}</b> &middot; {courtLabel(c)}</div>
                <Badge t="amber">watch cause list</Badge>
              </Row>
            ))}
          </div>
        </Sec>
      )}
    </div>
  );
}

/* ================= Register (case list) ================= */

function Register({ cases, openCase }) {
  const [q, setQ] = useState("");
  const [court, setCourt] = useState("All");
  const [status, setStatus] = useState("All");
  const [odOnly, setOdOnly] = useState(false);

  const list = useMemo(() => {
    const t = q.trim().toLowerCase();
    return cases
      .filter((c) => {
        if (court !== "All" && c.court !== court) return false;
        if (status !== "All" && c.status !== status) return false;
        if (odOnly && caseStats(c).od === 0) return false;
        if (!t) return true;
        const hay = [c.caseNumber, c.petitioners, c.gist, (c.respondents || []).join(" "), c.standingCounsel].join(" ").toLowerCase();
        return hay.includes(t);
      })
      .sort((a, b) => {
        const key = (c) => {
          if (c.status === "Closed") return 100000;
          const st = caseStats(c);
          const base = c.nextHearingDate ? daysFrom(c.nextHearingDate) + 500 : 9000;
          return (st.od > 0 ? 0 : 10000) + base;
        };
        return key(a) - key(b);
      });
  }, [cases, q, court, status, odOnly]);

  return (
    <div className="grid gap-3">
      <div className="card" style={{ padding: 12 }}>
        <div className="grid md:grid-cols-4 gap-2">
          <input className="inp md:col-span-2" placeholder="Search case no., petitioner, gist\u2026" value={q} onChange={(e) => setQ(e.target.value)} />
          <select className="inp" value={court} onChange={(e) => setCourt(e.target.value)}>
            <option>All</option>
            {COURTS.map((c) => <option key={c}>{c}</option>)}
          </select>
          <select className="inp" value={status} onChange={(e) => setStatus(e.target.value)}>
            {["All", "Active", "Disposed", "Closed"].map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>
        <label style={{ display: "flex", gap: 7, alignItems: "center", fontSize: 12.5, marginTop: 8, cursor: "pointer" }}>
          <input type="checkbox" checked={odOnly} onChange={(e) => setOdOnly(e.target.checked)} style={{ accentColor: "#1f5130" }} />
          Show only cases with overdue actions
        </label>
      </div>

      {list.length === 0 ? (
        <div className="card" style={{ padding: 16 }}><Empty>No cases match the current filters.</Empty></div>
      ) : (
        <div className="grid gap-2">
          {list.map((c) => {
            const st = caseStats(c);
            const d = c.nextHearingDate ? daysFrom(c.nextHearingDate) : null;
            return (
              <div key={c.id} className="card row" style={{ padding: "12px 14px", borderLeft: st.od > 0 ? "4px solid #d97706" : "4px solid transparent" }} onClick={() => openCase(c.id)}>
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div style={{ minWidth: 0 }}>
                    <div className="serif" style={{ fontSize: 15.5, fontWeight: 700 }}>{c.caseNumber}</div>
                    <div style={{ fontSize: 12.5, color: "#4a4f43" }}>{titleOf(c)}</div>
                  </div>
                  <div className="flex gap-1 flex-wrap justify-end">
                    <Badge t="blue">{courtLabel(c)}</Badge>
                    <Badge t="gray">{typeLabel(c)}</Badge>
                    <Badge t={caseStatusTone(c.status)}>{c.status}</Badge>
                  </div>
                </div>
                <div className="flex gap-1 flex-wrap mt-2">
                  {c.status === "Active" && (c.nextHearingDate
                    ? <Badge t={d < 0 ? "red" : d <= 7 ? "amber" : "green"}>{d < 0 ? "hearing passed " + fmtD(c.nextHearingDate) : "next: " + fmtD(c.nextHearingDate) + " (" + rel(d) + ")"}</Badge>
                    : <Badge t="amber">date not fixed</Badge>)}
                  {st.pend > 0 && <Badge t="gray">{st.pend} pending NA</Badge>}
                  {st.od > 0 && <Badge t="red">{st.od} overdue</Badge>}
                  {st.total > 0 && st.pend === 0 && <Badge t="green">all NAs completed</Badge>}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ================= My tasks ================= */

function TaskRow({ c, a, openCase, onAddUpdate }) {
  const [open, setOpen] = useState(false);
  const d = a.dueDate ? daysFrom(a.dueDate) : null;
  return (
    <div className="card" style={{ padding: "11px 13px", borderLeft: d !== null && d < 0 ? "4px solid #d97706" : "4px solid transparent" }}>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: 13.5, fontWeight: 700 }}>{actionLabel(a)}</div>
          <div style={{ fontSize: 12, color: "#5c6156", marginTop: 2 }}>
            <span className="link" onClick={() => openCase(c.id)}>{c.caseNumber}</span> &middot; {courtLabel(c)} &middot; due <b style={{ color: d < 0 ? "#a11a1a" : "#232620" }}>{fmtD(a.dueDate)}</b>
          </div>
        </div>
        <div className="flex gap-1">
          <Badge t={statusTone(a.currentStatus)}>{a.currentStatus}</Badge>
          {d !== null && d < 0 && <Badge t="red">{Math.abs(d)}d overdue</Badge>}
        </div>
      </div>
      <div className="mt-2 noprint">
        {open ? (
          <UpdateForm onCancel={() => setOpen(false)} onSave={(u) => { onAddUpdate(u); setOpen(false); }} />
        ) : (
          <button className="btn" onClick={() => setOpen(true)}>+ Add update</button>
        )}
      </div>
    </div>
  );
}

function MyTasks({ cases, me, openCase, addUpdate }) {
  if (!me) return <div className="card" style={{ padding: 16 }}><Empty>Select your officer name in the top bar to see the actions assigned to you.</Empty></div>;
  const mine = cases.flatMap((c) => (c.actions || []).filter((a) => a.officer === me).map((a) => ({ a, c })));
  const pending = mine.filter((x) => x.a.currentStatus !== "Completed" && x.c.status !== "Closed").sort((p, q) => (p.a.dueDate || "9999").localeCompare(q.a.dueDate || "9999"));
  const done = mine.length - pending.length;
  return (
    <div className="grid gap-3">
      <div style={{ fontSize: 13, color: "#5c6156" }}>
        Actions assigned to <b style={{ color: "#232620" }}>{me}</b>: {pending.length} pending{done > 0 ? ", " + done + " completed" : ""}.
      </div>
      {pending.length === 0 ? (
        <div className="card" style={{ padding: 16 }}><Empty>Nothing pending against your name. Well done.</Empty></div>
      ) : (
        <div className="grid gap-2">
          {pending.map(({ a, c }) => (
            <TaskRow key={a.id} c={c} a={a} openCase={openCase} onAddUpdate={(u) => addUpdate(c.id, a.id, u)} />
          ))}
        </div>
      )}
    </div>
  );
}

/* ================= App ================= */

/* ================= Access gate ================= */

function Gate({ onDone }) {
  const [k, setK] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const configured = scriptConfigured();
  const submit = async () => {
    if (!k.trim()) { setErr("Enter the access key circulated by the department."); return; }
    setBusy(true); setErr("");
    setAccessKey(k.trim());
    try {
      await api("ping", {});
      onDone();
    } catch (e) {
      clearAccessKey();
      setErr(e && e.code === "AUTH_KEY" ? "Incorrect access key. Please check with the administrator." : (e.message || "Could not reach the server."));
    } finally { setBusy(false); }
  };
  return (
    <div style={{ minHeight: "70vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
      <div className="card" style={{ padding: 22, maxWidth: 420, width: "100%" }}>
        <img src="./logo-full.png" alt="CCMS \u2014 Court Cases Monitoring System" style={{ display: "block", width: "82%", maxWidth: 300, height: "auto", margin: "2px auto 14px" }} />
        <div className="serif" style={{ fontSize: 20, fontWeight: 700, color: "#1f5130", textAlign: "center" }}>Court Case Monitoring System</div>
        <div style={{ fontSize: 12, color: "#6b7061", marginTop: 3, textAlign: "center" }}>Forest &amp; Allied Departments &middot; Government of Uttarakhand</div>
        {!configured ? (
          <div style={{ marginTop: 16, fontSize: 13.5, lineHeight: 1.55 }}>
            <b>Administrator setup pending.</b> The file <code>config.js</code> on the website does not yet contain the Google Apps Script URL. Please follow Step&nbsp;3 of the Setup Guide, then reload this page.
          </div>
        ) : (
          <div style={{ marginTop: 16 }}>
            <Field label="Department access key" req>
              <input className="inp" type="password" value={k} onChange={(e) => setK(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} placeholder="Enter access key" autoFocus />
            </Field>
            {err && <div style={{ color: "#a11a1a", fontSize: 12.5, marginTop: 8 }}>{err}</div>}
            <button className="btn btnP" style={{ width: "100%", marginTop: 12 }} disabled={busy} onClick={submit}>{busy ? "Checking\u2026" : "Enter"}</button>
            <div style={{ fontSize: 11, color: "#8a8f80", marginTop: 10 }}>One-time on this device. The key is circulated internally by the administrator and can be changed in the Google Sheet (Config tab).</div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ================= App ================= */

export default function App() {
  const [gateOk, setGateOk] = useState(() => scriptConfigured() && !!getAccessKey());
  const [cases, setCases] = useState([]);
  const [me, setMe] = useState(() => getIdentity());
  const [view, setView] = useState("dash");
  const [selId, setSelId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState(null);
  const [offlineAt, setOfflineAt] = useState(null); // ISO time of cached snapshot when offline

  const notify = (m, tone = "ok") => {
    setToast({ m, tone });
    setTimeout(() => setToast(null), 3600);
  };

  const handleErr = (e) => {
    if (e && e.code === "AUTH_KEY") {
      clearAccessKey();
      setGateOk(false);
      notify("Access key changed \u2014 please enter the new key", "err");
    } else {
      notify((e && e.message) || "Could not save \u2014 please retry", "err");
    }
  };

  const refresh = async () => {
    setLoading(true);
    try {
      const j = await api("list", {});
      setCases(j.cases || []);
      writeCache(j.cases || []);
      setOfflineAt(null);
    } catch (e) {
      if (e && e.code === "NETWORK") {
        const snap = readCache();
        if (snap) { setCases(snap.cases || []); setOfflineAt(snap.at); notify("Offline \u2014 showing last saved copy", "err"); }
        else notify("No connection and no saved copy on this device", "err");
      } else handleErr(e);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { if (gateOk) refresh(); }, [gateOk]);

  const pickMe = (v) => { setMe(v); setIdentity(v); };

  /* Every mutation goes to the server; the server returns the updated case
     (or ok for deletions) and enforces the append-only / ownership rules. */
  const run = async (action, payload, okMsg) => {
    setBusy(true);
    try {
      const j = await api(action, payload);
      if (j.case) {
        setCases((cs) => {
          const i = cs.findIndex((c) => c.id === j.case.id);
          const next = i === -1 ? [j.case, ...cs] : cs.map((c) => (c.id === j.case.id ? j.case : c));
          writeCache(next);
          return next;
        });
      } else if (j.deletedId) {
        setCases((cs) => { const next = cs.filter((c) => c.id !== j.deletedId); writeCache(next); return next; });
      }
      if (okMsg) notify(okMsg);
      return j;
    } catch (e) {
      handleErr(e);
      return null;
    } finally {
      setBusy(false);
    }
  };

  const needMe = () => {
    if (!me) {
      notify("First select your officer name in the top bar", "err");
      return false;
    }
    return true;
  };

  const openCase = (id) => { setSelId(id); setView("case"); };

  const createCase = async (data, actions) => {
    if (!needMe()) return;
    const c = { id: uid(), createdBy: me, createdAt: new Date().toISOString(), status: "Active", hearings: [], files: [], actions: actions || [], ...data };
    const j = await run("createCase", { case: c }, "Case saved \u2014 visible to all officers");
    if (j) { setSelId(c.id); setView("case"); }
  };

  const editCase = async (id, patch) => {
    const j = await run("editCase", { id, by: me, patch }, "Particulars updated");
    if (j) setView("case");
  };

  const patchCase = async (id, patch) => { await run("editCase", { id, by: me, patch }); };

  const deleteCase = async (id) => {
    if (!window.confirm("Delete this case and all its records? This cannot be undone.")) return;
    const j = await run("deleteCase", { id, by: me }, "Case deleted");
    if (j) setView("list");
  };

  const addHearing = async (id, h, disposed) => {
    if (!needMe()) return null;
    const hid = uid();
    const j = await run("addHearing", { id, by: me, hearing: { id: hid, by: me, at: new Date().toISOString(), ...h }, disposed: !!disposed }, "Hearing recorded");
    return j ? hid : null;
  };

  const addActions = async (id, acts) => {
    if (!needMe()) return;
    await run("addActions", { id, by: me, actions: acts }, acts.length + " action(s) added");
  };

  const addUpdate = async (caseId, actionId, u) => {
    if (!needMe()) return;
    await run("addUpdate", { id: caseId, actionId, by: me, update: { id: uid(), by: me, at: new Date().toISOString(), ...u } }, "Update recorded");
  };

  const deleteAction = async (caseId, actionId) => {
    await run("deleteAction", { id: caseId, actionId, by: me });
  };

  const uploadFile = async (caseId, file) => {
    if (!needMe()) return;
    if (file.size > MAX_FILE_BYTES) { notify("File too large \u2014 max 10 MB", "err"); return; }
    try {
      const dataUrl = await new Promise((res, rej) => {
        const r = new FileReader();
        r.onload = () => res(r.result);
        r.onerror = () => rej(new Error("read failed"));
        r.readAsDataURL(file);
      });
      const base64 = String(dataUrl).split(",")[1] || "";
      await run("uploadFile", { id: caseId, by: me, name: file.name, mime: file.type || "application/octet-stream", size: file.size, base64 }, "File saved to the department Drive");
    } catch (e) {
      notify("Upload failed \u2014 please retry", "err");
    }
  };

  const downloadFile = async (caseId, f) => {
    if (f && f.url) window.open(f.url, "_blank", "noopener");
    else notify("Could not fetch the file", "err");
  };

  const deleteFile = async (caseId, f) => {
    if (!window.confirm("Delete file \u201c" + f.name + "\u201d?")) return;
    await run("deleteFile", { id: caseId, fileId: f.id, by: me }, "File deleted");
  };

  const sel = cases.find((c) => c.id === selId);
  const H = { setView, patchCase, deleteCase, addHearing, addActions, addUpdate, deleteAction, uploadFile, downloadFile, deleteFile };

  const TabBtn = ({ v, children }) => (
    <button className={"tab" + (view === v ? " on" : "")} onClick={() => setView(v)}>{children}</button>
  );

  return (
    <div className="app">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Public+Sans:wght@400;500;600;700;800&display=swap');
        *{box-sizing:border-box} body{margin:0}
        .app{font-family:'Public Sans',system-ui,sans-serif;background:#f2efe6;min-height:100vh;color:#232620}
        .serif{font-family:'Fraunces',Georgia,serif}
        .inp{width:100%;padding:8px 10px;border:1px solid #cfc9b6;border-radius:8px;background:#fff;font:inherit;font-size:14px;color:#232620}
        .inp:focus{outline:2px solid rgba(45,106,79,.25);border-color:#2d6a4f}
        .inp:disabled{background:#eeece1;color:#8a8f80}
        textarea.inp{resize:vertical}
        .btn{border:1px solid #cfc9b6;background:#fff;border-radius:8px;padding:8px 14px;font:inherit;font-size:13px;font-weight:700;cursor:pointer;color:#2b2f2a}
        .btn:hover{background:#faf8f0}
        .btnP{background:#1f5130;border-color:#1f5130;color:#fff}
        .btnP:hover{background:#2d6a4f}
        .btnD{color:#a11a1a;border-color:#e3c3c3}
        .btn:disabled{cursor:not-allowed}
        .card{background:#fff;border:1px solid #e0dbc9;border-radius:12px}
        .lbl{font-size:10.5px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:#6b7061;margin-bottom:4px;display:block}
        .tab{padding:8px 14px;border-radius:999px;font-size:13px;font-weight:700;cursor:pointer;border:1px solid transparent;color:#3d4238;background:transparent}
        .tab.on{background:#1f5130;color:#fff}
        .tab:not(.on):hover{background:#e7e3d3}
        .row:hover{background:#faf8f0;cursor:pointer}
        .link{color:#1f5130;font-weight:700;text-decoration:underline;cursor:pointer}
        button{-webkit-tap-highlight-color:transparent}
        @media print{.noprint{display:none}}
      `}</style>

      {!gateOk ? (
        <Gate onDone={() => setGateOk(true)} />
      ) : (
      <>
      {/* Header */}
      <div style={{ background: "#262a24", borderBottom: "3px solid #d97706" }} className="noprint">
        <div className="max-w-5xl mx-auto px-4 py-3 flex flex-wrap items-center gap-3">
          <div style={{ flex: "1 1 220px", display: "flex", alignItems: "center", gap: 10 }}>
            <img src="./logo-badge.png" alt="CCMS logo" width="42" height="42" style={{ width: 42, height: 42, flex: "0 0 auto", borderRadius: "50%", background: "#fff" }} />
            <div>
              <div className="serif" style={{ color: "#f2efe6", fontSize: 19, fontWeight: 600, lineHeight: 1.15 }}>Court Case Monitoring System</div>
              <div style={{ color: "#a8ae9d", fontSize: 11, marginTop: 2, letterSpacing: ".02em" }}>&#2344;&#2381;&#2351;&#2366;&#2351;&#2366;&#2354;&#2351; &#2357;&#2366;&#2342; &#2309;&#2344;&#2369;&#2358;&#2381;&#2352;&#2357;&#2339; &#2346;&#2381;&#2352;&#2339;&#2366;&#2354;&#2368; &middot; Forest &amp; Allied Departments, Uttarakhand</div>
            </div>
          </div>
          <div className="flex items-end gap-2">
            <div style={{ minWidth: 200, maxWidth: 250 }}>
              <div style={{ color: "#8a9184", fontSize: 9.5, fontWeight: 800, letterSpacing: ".08em", marginBottom: 3 }}>I AM (OFFICER)</div>
              <OfficerSelect value={me} onChange={pickMe} dark />
            </div>
            <button className="btn" style={{ background: "#31352e", borderColor: "#4a4f45", color: "#f0eee4", padding: "6px 10px" }} title="Refresh \u2014 pull the latest entries by other officers" onClick={refresh}>
              {busy || loading ? "\u2026" : "\u21bb"}
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="noprint" style={{ background: "#eceadf", borderBottom: "1px solid #ded8c4", position: "sticky", top: 0, zIndex: 10 }}>
        <div className="max-w-5xl mx-auto px-3 py-2 flex flex-wrap items-center gap-1">
          <TabBtn v="dash">Dashboard</TabBtn>
          <TabBtn v="list">Case register</TabBtn>
          <TabBtn v="my">My tasks</TabBtn>
          <div style={{ flex: 1 }} />
          <button className="btn btnP" style={{ borderRadius: 999, padding: "7px 14px" }} onClick={() => setView("new")}>+ New case</button>
        </div>
      </div>

      {/* Body */}
      <div className="max-w-5xl mx-auto px-3 py-4" style={{ paddingBottom: 60 }}>
        {offlineAt && (
          <div className="card" style={{ padding: "8px 12px", marginBottom: 10, background: "#fbeed2", borderColor: "#e8cd93", color: "#8a5a08", fontSize: 12.5, fontWeight: 600 }}>
            Offline &mdash; read-only copy saved on this device on {fmtDT(offlineAt)}. Entries cannot be saved until connection returns. <span className="link" onClick={refresh}>Retry</span>
          </div>
        )}
        {loading ? (
          <div className="card" style={{ padding: 20, textAlign: "center", color: "#6b7061", fontSize: 13.5 }}>Loading the register&hellip;</div>
        ) : view === "dash" ? (
          <Dashboard cases={cases} openCase={openCase} goNew={() => setView("new")} />
        ) : view === "list" ? (
          <Register cases={cases} openCase={openCase} />
        ) : view === "my" ? (
          <MyTasks cases={cases} me={me} openCase={openCase} addUpdate={addUpdate} />
        ) : view === "new" ? (
          <CaseForm me={me} withNA title="New case \u2014 on receipt of notice" onCancel={() => setView("dash")} onSave={createCase} />
        ) : view === "edit" && sel ? (
          <CaseForm me={me} initial={sel} title={"Edit particulars \u2014 " + sel.caseNumber} onCancel={() => setView("case")} onSave={(data) => editCase(sel.id, data)} />
        ) : view === "case" && sel ? (
          <CaseDetail c={sel} me={me} H={H} />
        ) : (
          <div className="card" style={{ padding: 16 }}><Empty>This case is no longer available. <span className="link" onClick={() => setView("list")}>Back to the register</span></Empty></div>
        )}

        <div style={{ fontSize: 10.5, color: "#9b9f90", marginTop: 22, textAlign: "center" }} className="noprint">
          Entries are stored in the department's Google Sheet and are visible to every officer using this app. Officer identity is self-declared from the top bar. Action updates are append-only &mdash; the original entry of another user cannot be modified. Judgment copies are kept in the department's Google Drive.
          <div style={{ marginTop: 4 }}>
            <span className="link" style={{ color: "#9b9f90" }} onClick={() => { clearAccessKey(); setGateOk(false); }}>Change access key</span>
          </div>
        </div>
      </div>
      </>
      )}

      {/* Toast */}
      {toast && (
        <div style={{ position: "fixed", bottom: 16, left: "50%", transform: "translateX(-50%)", background: toast.tone === "err" ? "#a11a1a" : "#1f5130", color: "#fff", padding: "9px 16px", borderRadius: 999, fontSize: 13, fontWeight: 700, zIndex: 50, boxShadow: "0 4px 14px rgba(0,0,0,.25)", maxWidth: "92vw" }}>
          {toast.m}
        </div>
      )}
    </div>
  );
}
