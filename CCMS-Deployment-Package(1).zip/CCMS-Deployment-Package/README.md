# Court Case Monitoring System (CCMS)
Forest & Allied Departments · Government of Uttarakhand

A zero-cost court case tracking app for the whole department:
Google Sheet + Apps Script (database & server) + GitHub Pages (hosting) + PWA (installable on iOS, Android, Windows, Mac).

**Full instructions: see `CCMS-Setup-Guide.docx` (English) or `CCMS-Setup-Guide-Hindi.docx` (हिन्दी) in this package.** Short form:

1. **Google side** — New Google Sheet → Extensions ▸ Apps Script → paste `google-apps-script/Code.gs` → Run `setup()` once → change the access key in the Sheet's **Config!B1** → Deploy ▸ Web app (Execute as: **Me**, Access: **Anyone**) → copy the `/exec` URL.
2. **GitHub side** — New **public** repo → upload everything inside `website-upload/` → Settings ▸ Pages ▸ Deploy from branch (main, /root) → note the site address → edit `config.js` in the repo and paste the `/exec` URL.
3. **Circulate** the site address + access key. Officers open it and Add to Home Screen / Install.

## Folders
- `website-upload/` — ready-built site files; upload these to GitHub (Part B).
- `google-apps-script/Code.gs` — the backend; paste into Apps Script (Part A).
- `source/` — developer source (Vite + React). Only needed to modify the app: `npm install`, `npm run build`, then upload the new `dist/` contents to GitHub.

## Rules enforced by the server
Append-only action updates (nobody can edit another user's entry) · only the case creator edits/deletes a case · actions updatable only by the assigned officer or case creator · files (≤10 MB) stored in the department's Drive.

## Admin quick reference
- Live summary: Sheet ▸ **Register** tab (rebuilt on every change)
- Change/revoke access: edit **Config!B1**
- Backup: Sheet ▸ File ▸ Download ▸ Excel
- Update the app: re-upload files to the GitHub repo; officers get it automatically
