import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// base './' so the site works on GitHub Pages under /repo-name/
export default defineConfig({
  base: "./",
  plugins: [react()],
  build: { outDir: "dist", assetsDir: "assets" }
});
